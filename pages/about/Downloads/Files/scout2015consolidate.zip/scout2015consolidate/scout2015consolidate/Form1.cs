﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using System.IO;
using System.Globalization;


namespace scout2015consolidate
{
    public partial class Form1 : Form
    {

        DataTable mdt;
        List<List<string>> schedule;
        List<List<string>> logs;
        List<List<string>> rschedule;
        List<List<string>> resx;
        SortedDictionary<string, List<int>> teamdict;
        



        public Form1()
        {
            InitializeComponent();
            schedule = new List<List<string>>();
            rschedule = new List<List<string>>();
            logs = new List<List<string>>();
            mdt = new DataTable();
            teamdict = new SortedDictionary<string, List<int>>();
            resx = new List<List<string>>();
            
        }





        private void OpenFilex(ref List<List<string>> m, string sfn)
        {

            string[] sfld;
            string s;
            int ip = 0;
            int i = 0, ic = 0;
            int cc = 0;
                StreamReader sr = new StreamReader(sfn);
                while ((s = sr.ReadLine()) != null)
                {
                    //if () break;
                    if (s.Length > 0)
                    {
                        sfld = s.Split('\t');
                        ic = sfld.Length;
                        cc = m.Count;
                        m.Add(new List<string>());
                        for (i = 0; i < ic; i++) m[cc].Add(sfld[i]);
                    }
                    ip++;
                }

                sr.Close();
        }

        private void savetable(string fn, ref List<List<string>> xg)
        {
            string s = "";
            int ip = 0;
            int ipl = 0;
            int c, cc;
            StreamWriter sw = new StreamWriter(fn);
            ipl = xg.Count;

            for (ip = 0; ip < ipl; ip++)
            {
                
                s = "";
                cc = xg[ip].Count;
                for (c = 0; c < cc; c++)
                {
                    if (c > 0) s = s + "\t" + xg[ip][c];
                    else s = xg[ip][c];
                }
                sw.WriteLine(s);
            }
            sw.Close();
        }
        private void UpdateGrid(ref List<List<string>> mdx, int pos)
        {
            int i, r, ic, rc;
            ic = 0;
            rc = 0;
            int rb = 0;
            int re = 0;
            int rd = mdx.Count / 999;
            dataGridView1.DataSource = null;
            //lg = mdx;
            mdt.Clear();
            mdt.Columns.Clear();
            mdt.DefaultView.Sort = "";
            rc = mdx.Count;

            for (r = 0; r < rc; r++) if (mdx[r].Count > ic) ic = mdx[r].Count; // find max columns
            mdt.Columns.Add("row", typeof(string));

            for (i = 0; i < ic; i++) mdt.Columns.Add("Col" + i.ToString(), typeof(string));
            object[] myobj = new object[ic + 1];
            re = rc;
            rb = pos;
            if ((re - rb) > 10000) re = rb + 10000;
            for (r = rb; r < re; r++)
            {
                myobj[0] = r.ToString();
                for (i = 0; i < ic; i++)
                {
                    if (i < mdx[r].Count)
                    {
                        myobj[i + 1] = mdx[r][i];
                    }
                    else
                    {
                        myobj[i + 1] = "";
                    }
                }
                mdt.Rows.Add(myobj);
            }
            dataGridView1.DataSource = mdt;
            //toolStripStatusLabel1.Text = mdt.Rows.Count.ToString();
            //textBox2.Text = mdx.Count.ToString();
        }

        private void importLogsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i;
            DialogResult res;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "select logs";
            openFileDialog1.Multiselect = true;
            res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                logs.Clear();
                for (i = 0; i < openFileDialog1.FileNames.Length; i++)
                {
                    OpenFilex(ref logs, openFileDialog1.FileNames[i]);
                }
                UpdateGrid(ref logs, 0);
            }

        }

        private void saveLogsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            res = saveFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                savetable(saveFileDialog1.FileName, ref logs);
            }// end save file
        }

        private void qualScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i;
            DialogResult res;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Schedule";
            //openFileDialog1.Multiselect = true;
            res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                logs.Clear();
                for (i = 0; i < openFileDialog1.FileNames.Length; i++)
                {
                    OpenFilex(ref schedule, openFileDialog1.FileNames[i]);
                }
                UpdateGrid(ref schedule, 0);
            }

        }

        private void rawScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i;
            DialogResult res;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Raw Schedule";
            //openFileDialog1.Multiselect = true;
            res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                logs.Clear();
                for (i = 0; i < openFileDialog1.FileNames.Length; i++)
                {
                    OpenFilex(ref rschedule, openFileDialog1.FileNames[i]);
                }
                UpdateGrid(ref rschedule, 0);
            }
        }

        private void makeScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int r, rc, c, rx,i;
            rc = rschedule.Count;
            List<string> sfld=new List<string>();
            string[] sx;
            bool flag = false;
            schedule.Clear();
            schedule.Add(new List<string>());
            schedule[0].Add("Time");
            schedule[0].Add("Match");
            schedule[0].Add("R1");
            schedule[0].Add("R2");
            schedule[0].Add("R3");
            schedule[0].Add("B1");
            schedule[0].Add("B2");
            schedule[0].Add("B3");

            for (r = 0; r < rc; r++)
            {
                if (rschedule[r].Count > 1) // tab delimited
                {
                    sfld = rschedule[r];
                    if (sfld[0] == "1") flag = true;
                    if (sfld.Count < 10) flag = false;
                    if (flag && sfld.Count > 9)
                    {
                        if (sfld[1] == "Teams")
                        {
                            flag = false;
                        }
                        else
                        {
                            rx = schedule.Count;
                            schedule.Add(new List<string>());
                            for (c = 0; c < 8; c++) schedule[rx].Add("");
                            schedule[rx][1] = sfld[0];
                            schedule[rx][0] = sfld[1] ;
                            schedule[rx][2] = sfld[2];
                            schedule[rx][3] = sfld[3];
                            schedule[rx][4] = sfld[4];
                            schedule[rx][5] = sfld[5];
                            schedule[rx][6] = sfld[6];
                            schedule[rx][7] = sfld[7];
                        }


                    }
                }
                else
                {
                    sfld.Clear();
                    sx = rschedule[r][0].Split(' ');
                    for(i=0;i<sx.Length;i++) sfld.Add(sx[i]);
                    if (sfld[0] == "1") flag = true;
                    if (sfld.Count < 18) flag = false;
                    if (flag && sfld.Count > 18)
                    {
                        if (sfld[1] == "Teams" || sfld[0] == "Teams")
                        {
                            flag = false;
                        }
                        else
                        {
                            rx = schedule.Count;
                            schedule.Add(new List<string>());
                            for (c = 0; c < 8; c++) schedule[rx].Add("");
                            schedule[rx][1] = sfld[0];
                            schedule[rx][0] = sfld[1] + " " + sfld[2] + " " + sfld[4] + sfld[5];
                            schedule[rx][2] = sfld[7];
                            schedule[rx][3] = sfld[9];
                            schedule[rx][4] = sfld[11];
                            schedule[rx][5] = sfld[13];
                            schedule[rx][6] = sfld[15];
                            schedule[rx][7] = sfld[17];
                        }


                    }

                }
               
               
            }
            UpdateGrid(ref schedule, 0);
        }

        private void analyzeLogsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int r, rc,c;
            int ival = 0;
            rc = logs.Count;
            resx.Clear();
            teamdict.Clear();
            SortedDictionary<string, string> teamcom = new SortedDictionary<string, string>();
            for (r = 0; r < rc; r++)
            {
                if (!teamdict.ContainsKey(logs[r][1]))
                {
                    teamdict.Add(logs[r][1], new List<int>());
                    teamcom.Add(logs[r][1], "");
                    for (c = 0; c < 40; c++) teamdict[logs[r][1]].Add(0);
                }
                for (c = 0; c < 40; c++)
                {
                    ival = 0;
                    int.TryParse(logs[r][c + 3], out ival);
                    teamdict[logs[r][1]][c] = teamdict[logs[r][1]][c] + ival;
                }
                teamcom[logs[r][1]] = teamcom[logs[r][1]] + " "+logs[r][43];
            }
           
            resx.Add(new List<string>());
            //resx[0].Add("Team");
            //resx[0].Add("spare"); //0
            //resx[0].Add("totes1");
            //resx[0].Add("containers1");
            //resx[0].Add("liter1");
            //resx[0].Add("totes2");
            //resx[0].Add("containers2");
            //resx[0].Add("liter2");
            //resx[0].Add("totes3");
            //resx[0].Add("containers3");
            //resx[0].Add("liter3");
            //resx[0].Add("totes4");
            //resx[0].Add("containers4");
            //resx[0].Add("liter4");  //12
            //resx[0].Add("Liter landfill");
            //resx[0].Add("Liter field");
            //resx[0].Add("x15");
            //resx[0].Add("x16");
            //resx[0].Add("x17");
            //resx[0].Add("x18");
            //resx[0].Add("fouls");
            //resx[0].Add("AZ robot"); //20
            //resx[0].Add("AZ container");
            //resx[0].Add("AZ tote");
            //resx[0].Add("AZ toteset");
            //resx[0].Add("AZ totestack");
            //resx[0].Add("coop set"); //25
            //resx[0].Add("coop stack"); //26
            //resx[0].Add("Red"); //27
            //resx[0].Add("yellow"); //28
            //resx[0].Add("AZ container set"); //29
            //resx[0].Add("AZ robot set"); //30
            //resx[0].Add("x31");
            //resx[0].Add("x32");
            //resx[0].Add("x33");
            //resx[0].Add("x34");
            //resx[0].Add("x35");
            //resx[0].Add("x36");
            //resx[0].Add("x37");
            //resx[0].Add("x38");
            //resx[0].Add("rb123");
            //resx[0].Add("comment");
            //resx[0].Add("");

            resx[0].Add("Team");
            //resx[0].Add("spare"); //0
            resx[0].Add("totes");
            resx[0].Add("containers");
            resx[0].Add("liter");
            resx[0].Add("Liter landfill");
            resx[0].Add("Liter field");
            resx[0].Add("fouls");
            resx[0].Add("AZ robot"); //20
            resx[0].Add("AZ container"); //21
            resx[0].Add("AZ tote"); //22
            resx[0].Add("AZ toteset"); //23
            resx[0].Add("AZ totestack"); //24
            resx[0].Add("AZ container set"); //29
            resx[0].Add("AZ robot set"); //30
            resx[0].Add("coop set"); //25
            resx[0].Add("coop stack"); //26
            resx[0].Add("Red"); //27
            resx[0].Add("yellow"); //28
            resx[0].Add("landfill"); //31
            resx[0].Add("chute"); //32
            resx[0].Add("comment");




             foreach (KeyValuePair <string, List<int>> kp in teamdict)
            {
                r = resx.Count;
                resx.Add(new List<string>());
                resx[r].Add(kp.Key); //team
                resx[r].Add((kp.Value[1] + kp.Value[4] + kp.Value[7] + kp.Value[10]).ToString());
                resx[r].Add((kp.Value[2] + kp.Value[5] + kp.Value[8] + kp.Value[11]).ToString());
                resx[r].Add((kp.Value[3] + kp.Value[6] + kp.Value[9] + kp.Value[12]).ToString());
                resx[r].Add(kp.Value[13].ToString());
                resx[r].Add(kp.Value[14].ToString());
                resx[r].Add(kp.Value[19].ToString()); // fouls
                resx[r].Add(kp.Value[20].ToString()); //az r
                resx[r].Add(kp.Value[21].ToString()); //az c
                resx[r].Add(kp.Value[22].ToString()); //az t
                resx[r].Add(kp.Value[23].ToString()); //az tset
                resx[r].Add(kp.Value[24].ToString()); //az tstk
                resx[r].Add(kp.Value[29].ToString()); //az cset
                resx[r].Add(kp.Value[30].ToString()); //az rset

                resx[r].Add(kp.Value[25].ToString()); //az coop set
                resx[r].Add(kp.Value[26].ToString()); //az coop stk
                resx[r].Add(kp.Value[27].ToString()); //yel
                resx[r].Add(kp.Value[28].ToString()); //red
                resx[r].Add(kp.Value[31].ToString()); //landfill
                resx[r].Add(kp.Value[32].ToString()); //chute


                resx[r].Add(teamcom[kp.Key].Trim());
            }
              //                                1         2         3         4         5 
             //                       012345678901234567890123456789012345678901234567890123456789
             UpdateGridFmt(ref resx, "iiiiiiiiiiiiiiiiiiiis");
        }

        private void saveResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            res = saveFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                savetable(saveFileDialog1.FileName, ref resx);
            }// end save file
        }
        private void UpdateGridFmt(ref List<List<string>> mdx, string fmt)
        {
            int i, r, ic, rc;
            ic = 0;
            rc = 0;
            int ival = 0;
            double dval = 0;
            int rb = 0;
            int re = 0;
            int rd = mdx.Count / 999;
            dataGridView1.DataSource = null;
            //lg = mdx;
            mdt.Clear();
            mdt.Columns.Clear();
            mdt.DefaultView.Sort = "";
            rc = mdx.Count;

            for (r = 0; r < rc; r++) if (mdx[r].Count > ic) ic = mdx[r].Count; // find max columns
            mdt.Columns.Add("row", typeof(string));

            for (i = 0; i < ic; i++)
            {
                switch(fmt[i])
                {
                    case 's':
                        mdt.Columns.Add(mdx[0][i], typeof(string));
                        break;
                    case 'i':
                        mdt.Columns.Add(mdx[0][i], typeof(int));
                        break;
                    case 'd':
                        mdt.Columns.Add(mdx[0][i], typeof(double));
                        break;
                    default:
                        mdt.Columns.Add(mdx[0][i], typeof(string));
                        break;

                }
            }


            object[] myobj = new object[ic + 1];
            re = rc;
            rb = 1;
            if ((re - rb) > 10000) re = rb + 10000;
            for (r = rb; r < re; r++)
            {
                myobj[0] = r.ToString();
                for (i = 0; i < ic; i++)
                {
                    if (i < mdx[r].Count)
                    {
                        switch (fmt[i])
                        {
                            case 's':
                                myobj[i + 1] = mdx[r][i];
                                break;
                            case 'i':
                                int.TryParse(mdx[r][i], out ival);
                                myobj[i + 1] = ival;
                                break;
                            case 'd':
                                double.TryParse(mdx[r][i], out dval);
                                myobj[i + 1] = dval;
                                break;
                            default:
                                myobj[i + 1] = mdx[r][i];
                                break;

                        }

                    }
                    else
                    {
                        myobj[i + 1] = null;
                    }
                }
                mdt.Rows.Add(myobj);
            }
            dataGridView1.DataSource = mdt;
            //toolStripStatusLabel1.Text = mdt.Rows.Count.ToString();
            //textBox2.Text = mdx.Count.ToString();
        }

        private void saveScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            res = saveFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                savetable(saveFileDialog1.FileName, ref schedule);
            }// end save file
        }


    }
}
