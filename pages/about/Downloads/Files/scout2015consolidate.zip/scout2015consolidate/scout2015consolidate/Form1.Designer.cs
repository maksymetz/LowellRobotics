﻿namespace scout2015consolidate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importLogsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qualScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveLogsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rawScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveResultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.processToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analyzeLogsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.saveScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.processToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(618, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importLogsToolStripMenuItem,
            this.teamListToolStripMenuItem,
            this.qualScheduleToolStripMenuItem,
            this.saveLogsToolStripMenuItem,
            this.rawScheduleToolStripMenuItem,
            this.saveResultToolStripMenuItem,
            this.saveScheduleToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // importLogsToolStripMenuItem
            // 
            this.importLogsToolStripMenuItem.Name = "importLogsToolStripMenuItem";
            this.importLogsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.importLogsToolStripMenuItem.Text = "Import Logs";
            this.importLogsToolStripMenuItem.Click += new System.EventHandler(this.importLogsToolStripMenuItem_Click);
            // 
            // teamListToolStripMenuItem
            // 
            this.teamListToolStripMenuItem.Name = "teamListToolStripMenuItem";
            this.teamListToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.teamListToolStripMenuItem.Text = "Load Team List";
            // 
            // qualScheduleToolStripMenuItem
            // 
            this.qualScheduleToolStripMenuItem.Name = "qualScheduleToolStripMenuItem";
            this.qualScheduleToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.qualScheduleToolStripMenuItem.Text = "Load Qual Schedule";
            this.qualScheduleToolStripMenuItem.Click += new System.EventHandler(this.qualScheduleToolStripMenuItem_Click);
            // 
            // saveLogsToolStripMenuItem
            // 
            this.saveLogsToolStripMenuItem.Name = "saveLogsToolStripMenuItem";
            this.saveLogsToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveLogsToolStripMenuItem.Text = "Save logs";
            this.saveLogsToolStripMenuItem.Click += new System.EventHandler(this.saveLogsToolStripMenuItem_Click);
            // 
            // rawScheduleToolStripMenuItem
            // 
            this.rawScheduleToolStripMenuItem.Name = "rawScheduleToolStripMenuItem";
            this.rawScheduleToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.rawScheduleToolStripMenuItem.Text = "Raw Schedule";
            this.rawScheduleToolStripMenuItem.Click += new System.EventHandler(this.rawScheduleToolStripMenuItem_Click);
            // 
            // saveResultToolStripMenuItem
            // 
            this.saveResultToolStripMenuItem.Name = "saveResultToolStripMenuItem";
            this.saveResultToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveResultToolStripMenuItem.Text = "Save Analysis";
            this.saveResultToolStripMenuItem.Click += new System.EventHandler(this.saveResultToolStripMenuItem_Click);
            // 
            // processToolStripMenuItem
            // 
            this.processToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.analyzeLogsToolStripMenuItem,
            this.makeScheduleToolStripMenuItem});
            this.processToolStripMenuItem.Name = "processToolStripMenuItem";
            this.processToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.processToolStripMenuItem.Text = "Process";
            // 
            // analyzeLogsToolStripMenuItem
            // 
            this.analyzeLogsToolStripMenuItem.Name = "analyzeLogsToolStripMenuItem";
            this.analyzeLogsToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.analyzeLogsToolStripMenuItem.Text = "Analyze logs";
            this.analyzeLogsToolStripMenuItem.Click += new System.EventHandler(this.analyzeLogsToolStripMenuItem_Click);
            // 
            // makeScheduleToolStripMenuItem
            // 
            this.makeScheduleToolStripMenuItem.Name = "makeScheduleToolStripMenuItem";
            this.makeScheduleToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.makeScheduleToolStripMenuItem.Text = "Make Schedule";
            this.makeScheduleToolStripMenuItem.Click += new System.EventHandler(this.makeScheduleToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(129, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(477, 254);
            this.dataGridView1.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(111, 20);
            this.textBox1.TabIndex = 2;
            // 
            // saveScheduleToolStripMenuItem
            // 
            this.saveScheduleToolStripMenuItem.Name = "saveScheduleToolStripMenuItem";
            this.saveScheduleToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveScheduleToolStripMenuItem.Text = "Save Schedule";
            this.saveScheduleToolStripMenuItem.Click += new System.EventHandler(this.saveScheduleToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 328);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Procsess Scouting";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importLogsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qualScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem processToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analyzeLogsToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem saveLogsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rawScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makeScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveResultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveScheduleToolStripMenuItem;
    }
}

