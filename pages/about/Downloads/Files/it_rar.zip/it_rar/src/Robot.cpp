#include "WPILib.h"
#include "CxTimer.h"
#include "Motion.h"
#include "PosCntl.h"

class Robot: public IterativeRobot
{
private:
	LiveWindow *lw;


	// Channels for the wheels
	const static int frontLeftChannel	= 2;
	const static int rearLeftChannel	= 3;
	const static int frontRightChannel	= 1;
	const static int rearRightChannel	= 0;


	const static int joystickChannel	= 0;
	const static int ljoystickChannel	= 1;

	Joystick stick;			// only joystick
	Joystick lstick;
	CxTimer m_t1;
	CxTimer m_t2;
	CxTimer m_t3;
	Talon fLDrive;
	Talon rLDrive;
	Talon fRDrive;
	Talon rRDrive;
	Talon toteLift;
	RobotDrive robotDrive;	// robot drive system

	Encoder fLEnc;
	Encoder rLEnc;
	Encoder fREnc;
	Encoder rREnc;
	Encoder tLEnc;
	DigitalInput photoEye;
	DigitalInput autoswitch1;
	DigitalInput autoswitch2;
	DigitalInput autoswitch3;
	Solenoid recycleCylinder;
	Solenoid recycleCylext;
	Solenoid toteKicker;

	Motion fLMotion;
	Motion rLMotion;
	Motion fRMotion;
	Motion rRMotion;
	PosCntl tLiftMotion;

	float m_tlout=0;
	float m_rcout=0;
	float m_cufLenc=0;
	float m_curLenc=0;
	float m_cufRenc=0;
	float m_curRenc=0;
	float m_cutLenc=0;
	float m_oldtLenc=0;
	float m_boost=.5;
	float m_twist=.35;
	bool m_photoe=false;
	bool m_autosw1=false;
	bool m_autosw2=false;
	bool m_autosw3=false;
	bool m_firstCall=false;
	bool m_lstickbut2old=false;

	int m_autostep=0; // used to step through autonomous mode
	int m_autostepmax=0; // max number of steps
	int autopgnum=0;







public:
	Robot() :
		stick(joystickChannel), // these must be initialized in the same order
		lstick(ljoystickChannel),  // as they are declared above.
		m_t1(),
		m_t2(),
		m_t3(),
		fLDrive(frontLeftChannel),
		rLDrive(rearLeftChannel),
		fRDrive(frontRightChannel),
		rRDrive(rearRightChannel),
		toteLift(4),
		robotDrive(fLDrive, rLDrive, fRDrive, rRDrive),
		fLEnc(10,11),
		rLEnc(12,13),
		fREnc(14,15),
		rREnc(16,17),
		tLEnc(0,1),
		photoEye(2),
		autoswitch1(3),
		autoswitch2(4),
		autoswitch3(5),
		recycleCylinder(0),
		recycleCylext(1),
		toteKicker(3),
		fLMotion(.0225),
		rLMotion(.0225),
		fRMotion(.0225),
		rRMotion(.0225),
		tLiftMotion(.04)


{
		robotDrive.SetExpiration(0.1);
		robotDrive.SetInvertedMotor(RobotDrive::kFrontLeftMotor, true);	// invert the left side motors
		robotDrive.SetInvertedMotor(RobotDrive::kRearLeftMotor, true);	// you may need to change or remove this to match your robot
		fLDrive.SetExpiration(.1);
		rLDrive.SetExpiration(.1);
		fRDrive.SetExpiration(.1);
		rRDrive.SetExpiration(.1);
		toteLift.SetExpiration(.1);

		lw = LiveWindow::GetInstance();

}


	void RobotInit()
	{
		//lw = LiveWindow::GetInstance();
		robotDrive.SetSafetyEnabled(false);

	}

	void AutonomousInit()
	{
		m_t1.Update();
		m_t1.Reset();
		fLEnc.Reset();
		rLEnc.Reset();
		fREnc.Reset();
		rREnc.Reset();
		tLEnc.Reset();
		UpdateInputs();

		m_autostep = 0;

		toteLift.Set(0);
		fLDrive.Set(0);
		rLDrive.Set(0);
		fRDrive.Set(0);
		rRDrive.Set(0);

	}

	void AutonomousPeriodic()
	{
		UpdateInputs();
		autopgnum=0;
		if(m_autosw1) autopgnum=1;
		if(m_autosw2) autopgnum+=2;
		//if(m_autosw3) autopgnum+=4;



		switch (autopgnum)
		{
		case 0:
			AutonomousMode0();
			break;
		case 1:
			AutonomousMode1();
			break;
		case 2:
			AutonomousMode2();
			break;
		case 3:
			AutonomousMode3();
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		}





		if(m_autostep<m_autostepmax)
		{

		}
		else
		{
			m_autostep=m_autostepmax;
			toteLift.Set(0);
			fLDrive.Set(0);
			rLDrive.Set(0);
			fRDrive.Set(0);
			rRDrive.Set(0);
		}


		Wait(0.005); // wait 5ms to avoid hogging CPU cycles

	}



	void AutonomousMode0()  //pick up tote and can move to az
	{
		m_autostepmax=4;
		float lifth=1250;
		switch(m_autostep)
		{
		case 0:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,lifth));
			if(tLiftMotion.chkDone(m_cutLenc,lifth,200)) m_autostep++;
			break;
		case 1:
			if(RobotMotion(5, 2559, 2559, 2559, 2559)) m_autostep++; // 5 sec to position 134 inches
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,lifth));
			break;
		case 2:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			if(tLiftMotion.chkDone(m_cutLenc,0,20)) m_autostep++;
			break;
		case 3:
			toteLift.Set(0);
			if(RobotMotion(1, 2483, 2483, 2483, 2483)) m_autostep++;  // 1 sec to position 130 inches
			break;
		}
	}

	void AutonomousMode1()  // pick up three tote end wise
	{
		float lifth=800;
		//dfR   dfL   drR   drL
		float mm1[7][6]={
				{3.5 , 1501 , 1501 , 1501 , 1501 , 0.04 },
				{1 , 1615 , 1615 , 1615 , 1615 , 0.045 },
				{3.5 , 3116 , 3116 , 3116 , 3116 , 0.04 },
				{1 , 3230 , 3230 , 3230 , 3230 , 0.04 },
				{2 , 2679 , 3781 , 2679 , 3781 , 0.04 },
				{3 , 4674 , 5776 , 4674 , 5776 , 0.04 },
				{1 , 4636 , 5738 , 4636 , 5738 , 0.04 },
		};

		m_autostepmax=11;
		switch(m_autostep)
		{
		case 0:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,lifth));
			if(RobotMotion(mm1[0][0],mm1[0][1],mm1[0][2],mm1[0][3],mm1[0][4],mm1[0][5])) m_autostep++;
			break;
		case 1:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			if(tLiftMotion.chkDone(m_cutLenc,0,40)) m_autostep++;
			break;
		case 2:
			if(RobotMotion( mm1[1][0],mm1[1][1],mm1[1][2],mm1[1][3],mm1[1][4],mm1[1][5])) m_autostep++; 	// .75 sec to position 83 inches
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			break;
		case 3:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,lifth));
			if(RobotMotion(mm1[2][0],mm1[2][1],mm1[2][2],mm1[2][3],mm1[2][4],mm1[2][5])) m_autostep++;
			break;
		case 4:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			if(tLiftMotion.chkDone(m_cutLenc,0,20)) m_autostep++;
			break;
		case 5:
			if(RobotMotion(mm1[3][0],mm1[3][1],mm1[3][2],mm1[3][3],mm1[3][4],mm1[3][5])) m_autostep++; 	// .75 sec to position 164 inches
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			break;
		case 6:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			if(tLiftMotion.chkDone(m_cutLenc, 0,20)) m_autostep++;
			break;
		case 7:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,300)); 					// turn 640 each way
			if(RobotMotion(mm1[4][0],mm1[4][1],mm1[4][2],mm1[4][3],mm1[4][4],mm1[4][5])) m_autostep++;
			break;
		case 8:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,300));  					// 100 inches
			if(RobotMotion(mm1[5][0],mm1[5][1],mm1[5][2],mm1[5][3],mm1[5][4],mm1[5][5])) m_autostep++;
			break;
		case 9:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			if(tLiftMotion.chkDone(m_cutLenc, 0,50)) m_autostep++;
			break;
		case 10:
			if(RobotMotion(mm1[6][0],mm1[6][1],mm1[6][2],mm1[6][3],mm1[6][4],mm1[6][5])) m_autostep++;	//back up 1 in
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			break;
		}

	}
	void AutonomousMode2()  // pick up three tote from side and move to az
	{

		float mm2[5][6]={
				{4 , 1538 , -2070 , -2602 , 2070 , 0.04 },
				{1 , 1633 , -1975 , -2507 , 2165 , 0.045 },
				{4 , 3145 , -4019 , -5615 , 4741 , 0.04 },
				{3 , 5045 , -2119 , -3715 , 6641 , 0.04 },
				{1 , 5007 , -2157 , -3753 , 6603 , 0.045 },
		};

		m_autostepmax=9;
		switch(m_autostep)
		{
		case 0:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,1520)); // lift tote
			if(tLiftMotion.chkDone(m_cutLenc, 600,30)) m_autostep++;
			break;
		case 1:
			if(RobotMotion(mm2[0][0],mm2[0][1],mm2[0][2],mm2[0][3],mm2[0][4],mm2[0][5])) m_autostep++; // 5 sec strafe left 81 in, back 4 in
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,1520));
			break;
		case 2:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0)); // set tote down
			if(tLiftMotion.chkDone(m_cutLenc,0,20)) m_autostep++;
			break;
		case 3:
			if(RobotMotion(mm2[1][0],mm2[1][1],mm2[1][2],mm2[1][3],mm2[1][4],mm2[1][5])) m_autostep++; // 1 sec forward 1 inches
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));
			break;
		case 4:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,1520)); // lift totes
			if(tLiftMotion.chkDone(m_cutLenc, 600,30)) m_autostep++;
			break;
		case 5:
			if(RobotMotion(mm2[2][0],mm2[2][1],mm2[2][2],mm2[2][3],mm2[2][4],mm2[2][5])) m_autostep++; // 5 sec strafe left 81 in., back 4 in.
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,1520));
			break;
		case 6:
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,0)); // set tote down
			if(tLiftMotion.chkDone(m_cutLenc,0,20)) m_autostep++;
			break;
		case 7:
			if(RobotMotion(mm2[3][0],mm2[3][1],mm2[3][2],mm2[3][3],mm2[3][4],mm2[3][5])) m_autostep++; // 5 sec 134
			break;
		case 8:
			//toteLift.Set(-tLiftMotion.FB(m_cutLenc,800));
			if(RobotMotion(mm2[4][0],mm2[4][1],mm2[4][2],mm2[4][3],mm2[4][4],mm2[4][5])) m_autostep++; // 2 inch back.
			break;
		case 9:
			break;
		case 10:
			//toteLift.Set(-tLiftMotion.FB(m_cutLenc,0));  // change to release at 800
			//if(tLiftMotion.chkDone(m_cutLenc, 0,50)) m_autostep++; // change to release tote at layer 2
			break;
		case 11:
			//toteLift.Set(-tLiftMotion.FB(m_cutLenc, 0));
			//if(RobotMotion(mm2[5][0],mm2[5][1],mm2[5][2],mm2[5][3],mm2[5][4],mm2[5][5])) m_autostep++; // 1 sec backward 5 in.
			break;
		}

	}

	void AutonomousMode3()  // do nothing at all
	{

	}
	void AutonomousMode4()
	{
		//recycleCylinder(0),
		//recycleCylext(1),


		m_autostepmax=4;

		switch(m_autostep)
		{
		case 0:
			if(!m_t1.CkTime(true,300))
			{
				recycleCylinder.Set(false);
				recycleCylext.Set(true);
			}
			else
			{
				m_autostep++;
			}
			break;
		case 1:
			if(!m_t1.CkTime(true,300))
			{
				recycleCylinder.Set(true);
				recycleCylext.Set(true);
			}
			else
			{
				m_autostep++;
				m_t1.Reset();
			}
			break;
		case 2:
			if(!m_t1.CkTime(true,300))
			{
				recycleCylinder.Set(true);
				recycleCylext.Set(false);
			}
			else
			{
				m_autostep++;
				m_t1.Reset();
			}

			break;
		case 3:
			if(!m_t1.CkTime(true,300))
			{
				recycleCylinder.Set(false);
				recycleCylext.Set(false);
			}
			else
			{
				m_autostep++;
				m_t1.Reset();
			}
			break;
		case 4:
			if(!m_t1.CkTime(true,300))
			{
				recycleCylinder.Set(false);
				recycleCylext.Set(false);
			}
			else
			{
				m_autostep++;
				m_t1.Reset();
			}
			break;
		}

		toteLift.Set(0);
		fLDrive.Set(0);
		rLDrive.Set(0);
		fRDrive.Set(0);
		rRDrive.Set(0);


	}

	void TeleopInit()
	{
		UpdateInputs();
		m_autostep=0;

		robotDrive.MecanumDrive_Cartesian(-m_boost*stick.GetX(), -m_boost*stick.GetY(), -m_twist*stick.GetZ());
		toteLift.Set(0);


	}

	void TeleopPeriodic()
	{
		UpdateInputs();
		if(stick.GetRawButton(2)) // set not twist at all
		{
			m_boost = .4;
			m_twist = 0;
		}
		else if(stick.GetRawButton(1))// set normal
		{
			m_boost = 1;
			m_twist=.35;
		}
		else // set slow with twist
		{
			m_boost = .5;
			m_twist = .35;
		}


		if(stick.GetRawButton(8)) // front <-> back
		{
			fLDrive.Set(stick.GetY());
			rLDrive.Set(stick.GetY());
			fRDrive.Set(stick.GetY());
			rRDrive.Set(stick.GetY());
		}
		else if(stick.GetRawButton(9)) // left <-> right (straif)
		{
			//			fLDrive.Set(-fLMotion.GetPower(m_cufLenc, -1000, 6, .02, true, 10));
			//			rLDrive.Set(-rLMotion.GetPower(m_curLenc, 1000, 6, .02, true, 10));
			//			fRDrive.Set(fRMotion.GetPower(m_cufRenc, 1000, 6, .02, true, 10));
			//			rRDrive.Set(rRMotion.GetPower(m_curRenc, -1000, 6, .02, true, 10));
			//RobotMotion(false, 5, -24);
			fLDrive.Set(stick.GetY());
			rLDrive.Set(-stick.GetY());
			fRDrive.Set(stick.GetY());
			rRDrive.Set(-stick.GetY());
		}
		else
		{
			robotDrive.MecanumDrive_Cartesian(-m_boost*stick.GetX(), -m_boost*stick.GetY(), -m_twist*stick.GetZ());
		}

		// fix for current configuration
		if(lstick.GetRawButton(6)) recycleCylinder.Set(true); else recycleCylinder.Set(false);
		if(lstick.GetRawButton(11)) recycleCylext.Set(true); else recycleCylext.Set(false);
		if(lstick.GetRawButton(7)) toteKicker.Set(true); else toteKicker.Set(false);

		if(lstick.GetRawButton(9)) tLEnc.Reset();

		if(stick.GetRawButton(7)) // reset encoders
		{
			fLEnc.Reset();
			rLEnc.Reset();
			fREnc.Reset();
			rREnc.Reset();

		}


		if(lstick.GetRawButton(2))
		{
			if(m_lstickbut2old==false) m_oldtLenc=m_cutLenc;  // when button 8 first pressed get value to hold at
			toteLift.Set(-tLiftMotion.FB(m_cutLenc,m_oldtLenc));  // position regulate the current position
		}
		else if(lstick.GetRawButton(1))
		{
			toteLift.Set(-lstick.GetY());
		}
		else
		{
			toteLift.Set(0);
		}

		m_lstickbut2old=lstick.GetRawButton(2); // set current state of button to old
		Wait(0.005); // wait 5ms to avoid hogging CPU cycles

	}

	void UpdateInputs()
	{


		m_t1.Update();
		m_cufLenc=(float) fLEnc.Get();
		m_curLenc=(float) rLEnc.Get();
		m_cufRenc=(float) fREnc.Get();
		m_curRenc=(float) rREnc.Get();
		m_cutLenc=(float) tLEnc.Get();
		m_photoe=photoEye.Get();
		m_autosw1=autoswitch1.Get();
		m_autosw2=autoswitch2.Get();
		m_autosw3=autoswitch3.Get();

		SmartDashboard::PutNumber("m_cufRenc",m_cufRenc);
		SmartDashboard::PutNumber("m_cufLenc",m_cufLenc);
		SmartDashboard::PutNumber("m_curRenc",m_curRenc);
		SmartDashboard::PutNumber("m_curLenc",m_curLenc);
		SmartDashboard::PutNumber("m_cutLenc",m_cutLenc);
		SmartDashboard::PutNumber("m_oldtLenc",m_oldtLenc);

		SmartDashboard::PutBoolean("m_photoe",m_photoe);
		SmartDashboard::PutBoolean("m_autosw1",m_autosw1);
		SmartDashboard::PutBoolean("m_autosw2",m_autosw2);
		SmartDashboard::PutBoolean("m_autosw3",m_autosw3);

		SmartDashboard::PutNumber("autoNumber",autopgnum);
		SmartDashboard::PutNumber("stepNumber",m_autostep);

	}


	void TestPeriodic()
	{
		lw->Run();
	}
	bool RobotMotion(float time, float dfR, float dfL, float drR, float drL, float k = .02)
	{
		float tol = 2.5;

		fLDrive.Set(fLMotion.GetPower(m_cufLenc, dfL, time, k, true, tol));
		rLDrive.Set(rLMotion.GetPower(m_curLenc, drL, time, k, true, tol));
		fRDrive.Set(-fRMotion.GetPower(m_cufRenc, dfR, time, k, true, tol));
		rRDrive.Set(-rRMotion.GetPower(m_curRenc, drR, time, k, true, tol));

		return fLMotion.GetDone() && fRMotion.GetDone() && rLMotion.GetDone() && rRMotion.GetDone();
	}
};

START_ROBOT_CLASS(Robot);
