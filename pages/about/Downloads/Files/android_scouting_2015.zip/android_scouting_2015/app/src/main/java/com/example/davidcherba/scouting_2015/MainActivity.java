package com.example.davidcherba.scouting_2015;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

// my adds
import android.app.Activity;
import android.os.Environment;
import android.view.View;
import android.content.Context;
import android.widget.*;
import android.view.View.*;
import android.view.View.OnClickListener;
import android.widget.RadioGroup.OnCheckedChangeListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.io.*;



public class MainActivity extends ActionBarActivity {

    private int[] fldvalx=new int[40];


    private TextView stk1t; // stacks tote count
    private TextView stk2t;
    private TextView stk3t;
    private TextView stk4t;
    private TextView stk5t;
    private TextView stk6t;

    private TextView stk1c; //stacks container count
    private TextView stk2c;
    private TextView stk3c;
    private TextView stk4c;
    private TextView stk5c;
    private TextView stk6c;

    private TextView stk1l; //stacks litter
    private TextView stk2l;
    private TextView stk3l;
    private TextView stk4l;
    private TextView stk5l;
    private TextView stk6l;

    private EditText match;
    private EditText team;

    private RadioButton t1;
    private RadioButton t2;
    private RadioButton t3;

    private RadioButton red;
    private RadioButton blue;

    private RadioGroup rgteam;
    private RadioGroup rgcolor;

    private Button matchdoneb;
    private Button setmatch;
    private Button undo;
    private Button clearxfb;
    private Button decxfb;

    private CheckBox AZ_robotb;
    private CheckBox AZ_containerb;
    private CheckBox AZ_toteb;
    private CheckBox AZ_totesetb;
    private CheckBox AZ_totestackb;
    private CheckBox AZ_robotset;
    private CheckBox AZ_containerset;


    private CheckBox coop_setb;
    private CheckBox coop_stackb;

    private CheckBox red_cardb;
    private CheckBox yel_cardb;
    private TextView foul;
    private EditText comment;
    private CheckBox landfill;
    private CheckBox chute;


    private int matchnum=1;
    private String teamnums="0000";
    private String matchnums="1";
    private int teamsel=0;

    private int clearx=0;
    private int decrement=0;

    private List<String> matchsched=new ArrayList<String>(); //match schedule to drive team numbers
    private String matchres="";
    private String scoutstation="R1";
    private String ab="11:00 AM	0\t0000\t2851\t815\t3632\t3398\t123\t19\t0"; // debug string
    private String tabid="event_00";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            addListenerOn_stk1t();
            addListenerOn_stk1c();
            addListenerOn_stk1l();
            addListenerOn_stk2t();
            addListenerOn_stk2c();
            addListenerOn_stk2l();
            addListenerOn_stk3t();
            addListenerOn_stk3c();
            addListenerOn_stk3l();
            addListenerOn_stk4t();
            addListenerOn_stk4c();
            addListenerOn_stk4l();
            addListenerOn_stk5t();
            addListenerOn_stk5c();
            addListenerOn_stk5l();
            //addListenerOn_stk6t();
            //addListenerOn_stk6c();
            //addListenerOn_stk6l();
            addListenerOn_clearxf();
            addListenerOn_decxf();
            addListenerOn_foul();
            addListenerOn_matchdone();
            addListenerOn_setmatch();
            addListenerRadio_rgcolor();
            addListenerRadio_rgteam();
            getmatchschedule();
            gettabid();
            setmatchval();

    }

    public void clearall()
    {
        getradiostate();
        setmatchval();
        clearx=0;
        decrement=0;
        matchres="";
        stk1t=(TextView)findViewById(R.id.stk1t);
        stk1t.setText("0");
        fldvalx[1]=0;
        stk1c=(TextView)findViewById(R.id.stk1c);
        stk1c.setText("0");
        fldvalx[2]=0;
        stk1l=(TextView)findViewById(R.id.stk1l);
        stk1l.setText("0");
        fldvalx[3]=0;

        stk2t=(TextView)findViewById(R.id.stk2t);
        stk2t.setText("0");
        fldvalx[4]=0;
        stk2c=(TextView)findViewById(R.id.stk2c);
        stk2c.setText("0");
        fldvalx[5]=0;
        stk2l=(TextView)findViewById(R.id.stk2l);
        stk2l.setText("0");
        fldvalx[6]=0;

        stk3t=(TextView)findViewById(R.id.stk3t);
        stk3t.setText("0");
        fldvalx[7]=0;
        stk3c=(TextView)findViewById(R.id.stk3c);
        stk3c.setText("0");
        fldvalx[8]=0;
        stk3l=(TextView)findViewById(R.id.stk3l);
        stk3l.setText("0");
        fldvalx[9]=0;

        stk4t=(TextView)findViewById(R.id.stk4t);
        stk4t.setText("0");
        fldvalx[10]=0;
        stk4c=(TextView)findViewById(R.id.stk4c);
        stk4c.setText("0");
        fldvalx[11]=0;
        stk4l=(TextView)findViewById(R.id.stk4l);
        stk4l.setText("0");
        fldvalx[12]=0;

        stk5t=(TextView)findViewById(R.id.stk5t);
        stk5t.setText("0");
        fldvalx[13]=0;
        stk5c=(TextView)findViewById(R.id.stk5c);
        stk5c.setText("0");
        fldvalx[14]=0;
        stk5l=(TextView)findViewById(R.id.stk5l);
        stk5l.setText("0");
        fldvalx[15]=0;

        //stk6t=(TextView)findViewById(R.id.stk6t);
        //stk6t.setText("0");
        //fldvalx[16]=0;
        //stk6c=(TextView)findViewById(R.id.stk6c);
        //stk6c.setText("0");
        //fldvalx[17]=0;
        //stk6l=(TextView)findViewById(R.id.stk6l);
        //stk6l.setText("0");
        //fldvalx[18]=0;
        
        foul=(TextView) findViewById(R.id.foul);
        foul.setText("0");
        fldvalx[19]=0;
        
        AZ_robotb=(CheckBox) findViewById(R.id.AZ_robot);
        AZ_robotb.setChecked(false);
        
        AZ_containerb=(CheckBox) findViewById(R.id.AZ_container);
        AZ_containerb.setChecked(false);
        
        AZ_toteb=(CheckBox) findViewById(R.id.AZ_tote);
        AZ_toteb.setChecked(false);
        
        AZ_totesetb=(CheckBox) findViewById(R.id.AZ_toteset);
        AZ_totesetb.setChecked(false);
        
        AZ_totestackb=(CheckBox) findViewById(R.id.AZ_totestack);
        AZ_totestackb.setChecked(false);
        
        coop_setb=(CheckBox) findViewById(R.id.coop_set);
        coop_setb.setChecked(false);
        
        coop_stackb=(CheckBox) findViewById(R.id.coop_stack);
        coop_stackb.setChecked(false);

        red_cardb=(CheckBox) findViewById(R.id.red_card);
        red_cardb.setChecked(false);

        yel_cardb=(CheckBox) findViewById(R.id.yel_card);
        yel_cardb.setChecked(false);

        AZ_containerset=(CheckBox) findViewById(R.id.AZ_containerset);
        AZ_containerset.setChecked(false);

        AZ_robotset=(CheckBox) findViewById(R.id.AZ_robotset);
        AZ_robotset.setChecked(false);

        landfill=(CheckBox) findViewById(R.id.landfill);
        landfill.setChecked(false);

        chute=(CheckBox) findViewById(R.id.chute);
        chute.setChecked(false);

    }

    // loads fldvalx elements with status of check boxes
    public void getcheckbox()
    {
        AZ_robotb=(CheckBox) findViewById(R.id.AZ_robot);
        if(AZ_robotb.isChecked()) fldvalx[20]=1; else fldvalx[20]=0;

        AZ_containerb=(CheckBox) findViewById(R.id.AZ_container);
        if(AZ_containerb.isChecked()) fldvalx[21]=1; else fldvalx[21]=0;

        AZ_toteb=(CheckBox) findViewById(R.id.AZ_tote);
        if(AZ_toteb.isChecked()) fldvalx[22]=1; else fldvalx[22]=0;

        AZ_totesetb=(CheckBox) findViewById(R.id.AZ_toteset);
        if(AZ_totesetb.isChecked()) fldvalx[23]=1; else fldvalx[23]=0;

        AZ_totestackb=(CheckBox) findViewById(R.id.AZ_totestack);
        if(AZ_totestackb.isChecked()) fldvalx[24]=1; else fldvalx[24]=0;

        coop_setb=(CheckBox) findViewById(R.id.coop_set);
        if(coop_setb.isChecked()) fldvalx[25]=1; else fldvalx[25]=0;

        coop_stackb=(CheckBox) findViewById(R.id.coop_stack);
        if(coop_stackb.isChecked()) fldvalx[26]=1; else fldvalx[26]=0;

        red_cardb=(CheckBox) findViewById(R.id.red_card);
        if(red_cardb.isChecked()) fldvalx[27]=1; else fldvalx[27]=0;

        yel_cardb=(CheckBox) findViewById(R.id.yel_card);
        if(yel_cardb.isChecked()) fldvalx[28]=1; else fldvalx[28]=0;

        AZ_containerset=(CheckBox) findViewById(R.id.AZ_containerset);
        if(AZ_containerset.isChecked()) fldvalx[29]=1; else fldvalx[29]=0;

        AZ_robotset=(CheckBox) findViewById(R.id.AZ_robotset);
        if(AZ_robotset.isChecked()) fldvalx[30]=1; else fldvalx[30]=0;

        landfill=(CheckBox) findViewById(R.id.landfill);
        if(landfill.isChecked()) fldvalx[31]=1; else fldvalx[31]=0;

        chute=(CheckBox) findViewById(R.id.chute);
        if(chute.isChecked()) fldvalx[32]=1; else fldvalx[32]=0;

        match=(EditText) findViewById(R.id.match);
        matchnums=match.getText().toString();

        team=(EditText) findViewById(R.id.team);
        teamnums=team.getText().toString();


    }
    // figures out what alliance and team is set by radio buttons
    public void getradiostate()
    {
        teamsel=0;
        blue = (RadioButton) findViewById(R.id.blue);
        if(blue.isChecked()) teamsel=3; else teamsel=0;
        t2 = (RadioButton) findViewById(R.id.t2);
        if(t2.isChecked()) teamsel=teamsel+1;
        t3 = (RadioButton) findViewById(R.id.t3);
        if(t3.isChecked()) teamsel=teamsel+2;
        switch (teamsel)
        {
            case 0:
                scoutstation="R1";
                break;
            case 1:
                scoutstation="R2";
                break;
            case 2:
                scoutstation="R3";
                break;
            case 3:
                scoutstation="B1";
                break;
            case 4:
                scoutstation="B2";
                break;
            case 5:
                scoutstation="B3";
                break;

        }
        fldvalx[39]=teamsel;

    }
    // loads all the data into a tab delimited string
    public void buildres()
    {

        match=(EditText)findViewById(R.id.match);
        team=(EditText)findViewById(R.id.team);
        matchnums=match.getText().toString();
        teamnums=team.getText().toString();
        matchnum=Integer.parseInt(matchnums);

        int i=0; //loop through all the data value to add to string
        String temp=""; // temp string storage to rip out cr and lf
        //get the time and date stamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        StringBuilder sb = new StringBuilder(); // string to add all the values to then write to file
        sb.append(matchnums);sb.append('\t'); // add match number
        sb.append(teamnums);sb.append('\t'); // add team number
        sb.append(timeStamp); // add time stamp
        for(i=0;i<40;i++) // for each of the collected data items add the values
        {
            sb.append('\t');
            sb.append(Integer.toString(fldvalx[i]));
        }
        comment=(EditText)findViewById(R.id.comment); // get comment field
        sb.append('\t'); // add tab to keep comment separate
        temp=comment.getText().toString(); // get the comment
        temp=temp.replace('\n', ' '); // get rid of line feeds or CR entered
        temp=temp.replace('\r', ' ');
        sb.append(temp); // add to string
        sb.append('\r'); // put cr and lf on end
        sb.append('\n');
        matchres=sb.toString();

    }

    public void setmatchval()
    {
       comment=(EditText)findViewById(R.id.comment);
       match=(EditText)findViewById(R.id.match);
       team=(EditText)findViewById(R.id.team);

       teamnums="0000";
       matchnums="1";
        if(matchnum>matchsched.size()||matchnum<1) // set special info if match outside of range
        {
            matchnums=pxstr(ab,1);
            teamnums=pxstr(ab,2+teamsel);
            comment.setText("no schedule");
        }
        else // set correct match and team number
        {
            matchnums=pxstr(matchsched.get(matchnum),1);
            teamnums=pxstr(matchsched.get(matchnum),teamsel+2);
            comment.setText("");
        }
        match.setText(matchnums);
        team.setText(teamnums);
    }


    public void addListenerRadio_rgteam() // if team r1--b3 button hit set value and clear
    {
        rgteam=(RadioGroup) findViewById(R.id.rgteam);
        rgteam.setOnCheckedChangeListener(new OnCheckedChangeListener()
                                       {
                                              public void onCheckedChanged(RadioGroup rgteam,int checkedid)
                                              {
                                                  getradiostate();
                                                  setmatchval();
                                              }

                                          }
        );

    }

    public void addListenerRadio_rgcolor() // if team r1--b3 button hit set value and clear
    {
        rgcolor=(RadioGroup) findViewById(R.id.rgcolor);
        rgcolor.setOnCheckedChangeListener(new OnCheckedChangeListener()
                                          {
                                              public void onCheckedChanged(RadioGroup rgcolor,int checkedid)
                                              {
                                                  getradiostate();
                                                  setmatchval();
                                              }

                                          }
        );

    }

    public void addListenerOn_matchdone() {
        matchdoneb = (Button) findViewById(R.id.matchdone);

        matchdoneb.setOnClickListener(new OnClickListener() {
                                       public void onClick(View view) {
                                           // build string results
                                           getradiostate();
                                           getcheckbox();
                                           buildres();

                                           // save to log file
                                           savelog(tabid);

                                           // clear all
                                          matchnum++;
                                          clearall();
                                       }
                                   }
        );
    }

    public void addListenerOn_setmatch() {
        setmatch = (Button) findViewById(R.id.setmatch);
        match=(EditText)findViewById(R.id.match);
        setmatch.setOnClickListener(new OnClickListener() {
                                          public void onClick(View view) {

                                              matchnum=Integer.parseInt(match.getText().toString());
                                              setmatchval();
                                          }
                                      }
        );
    }

    public void addListenerOn_clearxf() {
        clearxfb = (Button) findViewById(R.id.clearxf);
        clearxfb.setOnClickListener(new OnClickListener() {
                                       public void onClick(View view) {
                                           if (clearx == 0) clearx = 1;
                                           else clearx = 0;
                                       }
                                   }
        );
    }

    public void addListenerOn_decxf() {
        decxfb = (Button) findViewById(R.id.decxf);
        decxfb.setOnClickListener(new OnClickListener() {
                                     public void onClick(View view) {
                                         if (decrement == 0) decrement = 1;
                                         else decrement = 0;
                                     }
                                 }
        );
    }

    public void addListenerOn_foul()
    {

        foul=(TextView) findViewById(R.id.foul);
        foul.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=19;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         foul.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk1t()
    {

        stk1t=(TextView) findViewById(R.id.stk1t);
        stk1t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=1;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk1t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk1c()
    {
        stk1c=(TextView) findViewById(R.id.stk1c);
        stk1c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=2;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk1c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk1l()
    {

        stk1l=(TextView) findViewById(R.id.stk1l);
        stk1l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=3;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk1l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk2t()
    {

        stk2t=(TextView) findViewById(R.id.stk2t);
        stk2t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=4;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk2t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk2c()
    {
        stk2c=(TextView) findViewById(R.id.stk2c);
        stk2c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=5;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk2c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk2l()
    {

        stk2l=(TextView) findViewById(R.id.stk2l);
        stk2l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=6;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk2l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk3t()
    {

        stk3t=(TextView) findViewById(R.id.stk3t);
        stk3t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=7;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk3t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk3c()
    {
        stk3c=(TextView) findViewById(R.id.stk3c);
        stk3c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=8;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk3c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk3l()
    {

        stk3l=(TextView) findViewById(R.id.stk3l);
        stk3l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=9;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk3l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk4t()
    {

        stk4t=(TextView) findViewById(R.id.stk4t);
        stk4t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=10;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk4t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk4c()
    {
        stk4c=(TextView) findViewById(R.id.stk4c);
        stk4c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=11;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk4c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk4l()
    {

        stk4l=(TextView) findViewById(R.id.stk4l);
        stk4l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=12;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk4l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }

    // stack 5 converted to counting litter
    public void addListenerOn_stk5t()
    {

        stk5t=(TextView) findViewById(R.id.stk5t);
        stk5t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=13;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk5t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk5c()
    {
        stk5c=(TextView) findViewById(R.id.stk5c);
        stk5c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=14;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }
                                         stk5c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk5l()
    {

        stk5l=(TextView) findViewById(R.id.stk5l);
        stk5l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=15;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }
                                         stk5l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }

    /* jumper out as test
    public void addListenerOn_stk6t()
    {

        stk6t=(TextView) findViewById(R.id.stk6t);
        stk6t.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {

                                         int i=16;
                                         if(clearx==1) {
                                             fldvalx[i] = 0;
                                             clearx=0;
                                         }
                                         else if(decrement==1) {
                                             if(fldvalx[i]>0) fldvalx[i]--;
                                             decrement=0;
                                         }
                                         else {
                                             fldvalx[i]++;
                                         }

                                         stk6t.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk6c()
    {
        stk6c=(TextView) findViewById(R.id.stk6c);
        stk6c.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=17;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk6c.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }
    public void addListenerOn_stk6l()
    {

        stk6l=(TextView) findViewById(R.id.stk6l);
        stk6l.setOnClickListener(new OnClickListener()
                                 {
                                     public void onClick(View view)
                                     {
                                         int i=18;
                                         if(fldvalx[i]==0) fldvalx[i]=1; else fldvalx[i]=0;
                                         stk6l.setText(Integer.toString(fldvalx[i]));
                                     }
                                 }
        );

    }

    */

    // get match schedule
    // expects header with time, match r1 r2 r3 b1 b2 b3
    // this is prepared from screen scrap of match schedule
    private void getmatchschedule()
    {
        matchsched.clear(); // clear any previous schedul
        String line=null;
        StringBuilder sb=new StringBuilder(); // debug on reading of file
        comment=(EditText)findViewById(R.id.comment); // put debug info in text box
        //get path to downloads directory
        File path=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        sb.append(path);//debug
        File myfile=new File(path,"matchsched.txt"); // get matchsched file handle
        try
        {
            BufferedReader inos=new BufferedReader(new FileReader(myfile)); //open for reading

            while((line=inos.readLine())!=null) // read until no more lines
            {
                matchsched.add(line); // add line to match schedule list
            }

            matchsched.add(""); // add blank line
            inos.close();// close the file reader
        }
        catch(IOException e) // if error put debug info into text box
        {
            sb.append("3 ");
            sb.append(e);
            comment.setText(sb.toString());
        }

        comment.setText(Integer.toString(matchsched.size()));


    }

    private void gettabid()
    {

        String line=null;
        StringBuilder sb=new StringBuilder(); // debug on reading of file
        comment=(EditText)findViewById(R.id.comment); // put debug info in text box
        //get path to downloads directory
        File path=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        sb.append(path);//debug
        File myfile=new File(path,"tabid.txt"); // get matchsched file handle
        try
        {
            BufferedReader inos=new BufferedReader(new FileReader(myfile)); //open for reading

            while((line=inos.readLine())!=null) // read until no more lines
            {
                tabid=line; // get tab id
            }
            inos.close();// close the file reader
        }
        catch(IOException e) // if error put debug info into text box
        {
            sb.append("3 ");
            sb.append(e);
            comment.setText(sb.toString());
        }

        comment.setText(Integer.toString(matchsched.size()));


    }
    // at end of match save the log of all the end of cycle,auto,match to the file
    private void savelog(String fn)
    {
        int i=0;
        String fnx=fn+"_matchlog.txt"; //robot plus base name of file
        StringBuilder sb=new StringBuilder(); //build up debug string for if file open fails
        //start with the path to the downloads directory
        File path=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        sb.append(path); //debug code
        File myfile=new File(path,fnx); // get new file in path
        sb.append(myfile); // debug code
        comment=(EditText)findViewById(R.id.comment);
        sb.append("1 "); //debug code
        byte [] bd;
        try
        {
            OutputStream os=new FileOutputStream(myfile,true); //finally open file for write append
            sb.append("2 ");

            bd=matchres.getBytes(); // get string into byte arrays
            os.write(bd); // write to file

            os.flush(); // finish off any strays
            os.close(); //close file
            //comment.setText(sb.toString());

        }
        catch(IOException e) // if file error put history into textbox
        {
            sb.append("3 ");
            sb.append(e);
            comment.setText(sb.toString());
        }


    }

    // takes an string from the match schedule and return the field pointed to by ip
    private String pxstr(String sx, int ip)
    {
        String sr="";
        String [] sfld=sx.split("\t"); // split the match schedule string in fields by tab char
        if (sfld.length>ip) // make sure string is at least ip long
        {
            sr=sfld[ip];  //return the string from that field

        }
        return sr;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
